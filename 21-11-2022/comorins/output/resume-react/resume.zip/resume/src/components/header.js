import UserContext from "../store/UserContext";
import {useContext} from 'react'

export default function Header(){
    const value = useContext(UserContext);
    const {isLogged,setIsLogged,currentUser} = value;
    return(
        <>
            <div className="bg-dark">
                <h2 className="text-light">Welcome!! {currentUser.name}</h2>
            </div>
        </>
    )
}