// import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import MainRouter from './routers';

function App() {
  return (
    <div className="App">
      <MainRouter />
    </div>
  );
}

export default App;
