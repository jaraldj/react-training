import React,{useState, useEffect} from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export default function InputForm(){

    const [resumePost, setResumePost] = useState({
        name: '',
        email: '',
        phoneNumber: '',
        role: '',
        skills: [],
        education : [],
        project : [],
        experiance : [],
        personalDetails : {}
    })
    const [resumes, setResumes] = useState({
        request: "create_react_resume",
        user : "jaraldj",
        resume : ''
    })
    console.log(resumes)

    const [viewResumeData, setViewResumeData] = useState()

    const [resumeSkills, setResumeSkills] = useState([])
    // console.log(resumeSkills);

    const [resumeEducation, setResumeEducation]= useState({
        // course: "",
        // year: "",
        // institute: "",
        // percentage: ""
    })

    const [resumeProject, setResumeProject] = useState({})

    const [resumeExperiance, setResumeExperiance] = useState({})

    useEffect(()=>{
        resumeUpdate()
        // getApi()
    },[resumePost])

    useEffect(()=>{
        getApi()
    },[])

    const resumeUpdate = () => {
        setResumes({...resumes,resume:resumePost})
    }

    const onResumeUpdate = (Key, value) => {
        let update;
        
       update={...resumePost,[Key]:value}
       setResumePost(update)
   

    }
    const addSkills = () =>{
        let skillLi = [...resumePost.skills,resumeSkills]
        setResumePost({...resumePost,skills:skillLi})
        setResumeSkills('')
    }

    const deleteSkill = (index) => {
        let newSkill = resumePost.skills.filter((skill, indexs) => indexs !== index)
        setResumePost({...resumePost,skills:newSkill})
    }
    // console.log(resumePost);

    const add_Education = (key, value) => {
        // let educationLi = [{...resumeEducation,[key]:value}]
        setResumeEducation({...resumeEducation,[key]:value})
    }
    const addEducation = () =>{
        let educationLi = [...resumePost.education,resumeEducation]
        setResumePost({...resumePost,education:educationLi})
        setResumeEducation({...resumePost.education,course:'',year:'',institute:'',percentage:''})
    }
    const deleteEducationLi= (index) => {
        let newEducationLi = resumePost.education.filter((edu, indexs) => indexs !== index)
        setResumePost({...resumePost,education:newEducationLi})
    }
    


    const add_Project = (key, value) => {
        setResumeProject({...resumeProject,[key]:value})
    }

    const addProject = () => {
        let projectLi = [...resumePost.project, resumeProject]
        setResumePost({...resumePost,project:projectLi})
        setResumeProject({...resumePost.project,project_title:'',project_abstract:''})
    }
    const deleteProjectLi = (index) => {
        let newProjectLi = resumePost.project.filter((project, indexes)=> indexes != index)
        setResumePost({...resumePost,project:newProjectLi})
    }



    const add_Experiance = (key,value) => {
        setResumeExperiance({...resumeExperiance,[key]:value})
    }

    const addExp = () => {
        let expLi = [...resumePost.experiance, resumeExperiance]
        setResumePost({...resumePost, experiance:expLi})
        setResumeExperiance({...resumePost.experiance,company_name:'', position:'',years:''})
    }
    const deleteExpLi = (index) => {
        let newExpLi = resumePost.experiance.filter((exp, indexes)=> indexes != index)
        setResumePost({...resumePost,experiance:newExpLi})
    }
    


    const submitResume = async() =>{
        console.log(resumes);
        const responce = await axios.post('http://karka.academy/api/action.php',JSON.stringify(resumes))
        console.log(responce.data);
        setResumePost({...resumePost,name:''})
    }



    const getApi = async() => {
        const {data} = await axios.get('http://karka.academy/api/action.php?request=get_user_react_resume&user=jaraldj')
        setViewResumeData(data.data)
        console.log(data.data);
    }
    // console.log(JSON.parse(viewResumeData.data).name);

    // console.log(...viewResumeData.email)

    const delete_resume = async(id) => {
        const del_id=await axios.get(`http://karka.academy/api/action.php?request=delete_react_user_resume&user=jaraldj&id=${id}`)
        getApi()
    }

    return (
        <div className="container">
            <label>Name : </label>
                <input type="text" value={resumePost.name} onChange={(e)=>onResumeUpdate('name', e.target.value)}/><br/><br/>
            <label>Email : </label>
                <input type="email" onChange={(e)=>onResumeUpdate('email', e.target.value)}/><br/><br/>
            <label>Phone number : </label>
                <input type="number" onChange={(e)=>onResumeUpdate('phoneNumber', e.target.value)}/><br/><br/>
            <label>Role : </label>
                <input type="text" onChange={(e)=>onResumeUpdate('role', e.target.value)}/><br/><br/>
            <label>Skills : </label>
                <input type="text" value={resumeSkills} onChange={(e)=>setResumeSkills(e.target.value)}/>
                <button onClick={addSkills}>+</button><br/><br/>

                {resumePost.skills.map((data,index)=>{
                    return (
                        <div key={index}>
                            <p>{data} <button onClick={()=>deleteSkill(index)}>Delete</button></p>
                        </div>
                    )
                })}

            <label>Education : </label>
                <table>
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Year</th>
                            <th>Institute</th>
                            <th>Percentage</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><input type="text" value={resumeEducation.course} onChange={(e)=>add_Education('course', e.target.value)}/></td>
                        <td><input type="number" value={resumeEducation.year} onChange={(e)=>add_Education('year', e.target.value)}/></td>
                        <td><input type="text" value={resumeEducation.institute} onChange={(e)=>add_Education('institute', e.target.value)}/></td>
                        <td><input type="text" value={resumeEducation.percentage} onChange={(e)=>add_Education('percentage', e.target.value)}/></td>
                        <td><button onClick={addEducation}>+</button></td>
                        
                    </tr>
                </tbody>
                </table>

                <table className="table">
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Year</th>
                            <th>Institute</th>
                            <th>Percentage</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    {resumePost.education.map((value,key, index)=>{
                        return (
                            <>
                                    <tbody key={index}>
                                        <tr>
                                            <td className="col-3">{value.course}</td>
                                            <td className="col-2">{value.year}</td>
                                            <td className="col-4">{value.institute}</td>
                                            <td className="col-2">{value.percentage}</td>
                                            <td><button onClick={()=>deleteEducationLi(key,index)}>Delete</button></td>
                                        </tr>
                                    </tbody>
                            </>
                        )
                    })}
                </table>

            <label>Project</label>
                    <table>
                        <thead>
                            <tr>
                                <th>Project Title</th>
                                <th>Abstract</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="text" value={resumeProject.project_title} onChange={(e)=>add_Project('project_title', e.target.value)} /></td>
                                <td><input type="text" value={resumeProject.project_abstract} onChange={(e)=>add_Project('project_abstract', e.target.value)} /></td>
                                <td><button onClick={addProject}>+</button></td>
                            </tr>
                        </tbody>
                    </table>

                    <table className="table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Abstract</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    {resumePost.project.map((value, index)=>{
                        return (
                            <>
                                    <tbody key={index}>
                                        <tr>
                                            <td className="col-5">{value.project_title}</td>
                                            <td className="col-6">{value.project_abstract}</td>
                                            <td><button onClick={()=>deleteProjectLi(index)}>Delete</button></td>
                                        </tr>
                                    </tbody>
                            </>
                        )
                    })}
                </table>

            <label>Experiance</label>
            <table>
                        <thead>
                            <tr>
                                <th>Company Name</th>
                                <th>Position</th>
                                <th>Experiance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="text" value={resumeExperiance.company_name} onChange={(e)=>add_Experiance('company_name', e.target.value)} /></td>
                                <td><input type="text" value={resumeExperiance.position} onChange={(e)=>add_Experiance('position', e.target.value)} /></td>
                                <td><input type="text" value={resumeExperiance.years} onChange={(e)=>add_Experiance('years', e.target.value)} /></td>
                                <td><button onClick={addExp}>+</button></td>
                            </tr>
                        </tbody>
                    </table>


                    <table className="table">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Position</th>
                            <th>Experiance</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    {resumePost.experiance.map((value, index)=>{
                        return (
                            <>
                                    <tbody key={index}>
                                        <tr>
                                            <td className="col-4">{value.company_name}</td>
                                            <td className="col-4">{value.position}</td>
                                            <td className="col-2">{value.years}</td>
                                            <td><button onClick={()=>deleteExpLi(index)}>Delete</button></td>
                                        </tr>
                                    </tbody>
                            </>
                        )
                    })}
                </table>

                {/* <label>Personal Details</label>
                    <label>Nationality :</label>
                        <input type="text" onChange={(e)=>onResumeUpdate('nationality', e.target.value)}/> */}
        
                {/* <button type="button" onClick={()=>{
        setResumes({...resumes,resume:resumePost})}}>Check</button> */}
        <button type="button" onClick={()=>{submitResume();getApi()}}>Submit</button>

        {/* <button type="button" onClick={getApi}>Get Resume</button> */}

        {viewResumeData && viewResumeData.map((val, index)=>{
        return (
            <div key={index}>
    
                <table className='table'>
                          <tbody >
                         
                            <tr >
                                <td>
                                    {index+1}
                                </td>
                                <td className='col-5'>
                                    {JSON.parse(val.data).name}
                                </td>
                                <td>
                                    <button className='btn btn-danger' onClick={()=>delete_resume(val.id)}>Delete</button>
                                </td>
                                <td>
                                    <button><Link to={`/view/${val.id}`}>View</Link></button>
                                </td>
                            </tr>
                          </tbody>
                       </table>
            </div>
        )
    })}
        </div>
    )
    

   
}