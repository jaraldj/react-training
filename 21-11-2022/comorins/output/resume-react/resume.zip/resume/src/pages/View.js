import axios from "axios"
import { useParams } from "react-router-dom"
import { useEffect, useState } from "react"

export default function View(){

    const params = useParams()

    const [view, setView] = useState()
    console.log(view);
    useEffect(()=>{
        getCurrentResume(params.id)
    },[params.id])

    const getCurrentResume = async() => {
        const {data} = await axios.get(`https://karka.academy/api/action.php?request=get_react_resume_by_id&user=jaraldj&id=${params.id}`)
        setView(data.data);

    }
    console.log(view);
    
    return (
        <div className="container">
            <h2>View Page</h2>

        {view && <div className="container">
            <h3>Name: {JSON.parse(view.data).name}</h3>
            <h3>email: {JSON.parse(view.data).email}</h3>
            <h3>Phone: {JSON.parse(view.data).phoneNumber}</h3>
            <h3>Role: {JSON.parse(view.data).role}</h3>
            <h3>Skills: <h6>{JSON.parse(view.data).skills.map((val, i)=>{
                return(
                    <div>
                        <ul>
                            <li>{val}</li>
                        </ul>
                    </div>
                )
            })}</h6></h3>
            <h3>Education:
            <table className="table">
                <thead>
                  <tr>
                    <th scope="col">Study</th>
                    <th scope="col">Institute</th>
                    <th scope="col">Percentage</th>
                    <th scope="col">Year</th>
                  </tr>
                </thead>
                <tbody>
             {JSON.parse(view.data).education.map((val, i)=>{
                return(
                    <tr>
                <td>{val.course}</td>
                <td>{val.year}</td>
                <td>{val.institute}</td>
                <td>{val.percentage}</td>
                
              </tr>
                )
                
            })}
            </tbody>
            </table>
            </h3>
            <h3>Project: {JSON.parse(view.data).project.map((val, i)=>{
                return(
                    <tr>
                        <td>{val.project_title}</td>
                        <td>{val.project_abstract}</td>
                    </tr>
                    
                )
                
            })}</h3>
        </div>
        }
        </div>
        
        
    )
}