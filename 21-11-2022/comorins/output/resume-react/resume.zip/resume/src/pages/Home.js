import Header from '../components/header'
import UserContext from "../store/UserContext";
import {useContext} from 'react'
import Form from './Form';
import InputForm from './InputForm';

export default function Home(){

    const value = useContext(UserContext);
    const {isLogged,setIsLogged,currentUser} = value;
    // alert(`Welcome ${currentUser.name}`)
    console.log(currentUser.name);

    return (
        <>
            <Header />
            <h2>Home</h2>
            <InputForm />
        
    
            
        </>
    )
}